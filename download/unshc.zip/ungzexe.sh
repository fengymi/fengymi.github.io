#!/bin/bash
# Mr.Wang
# gzexe解密工具

skip=`head -n +8 $1 | grep "skip" | cut -d = -f2`

name=$1

if [[ skip -gt 0 ]]; then

	name="$1.Mr.Wang"

	tail -n +${skip} $1 > $name.gz

	rm -rf "$name"

	gunzip "${name}.gz"

	echo -e "\033[32;40mOK\033[0m"

fi

bash unshc.sh $name